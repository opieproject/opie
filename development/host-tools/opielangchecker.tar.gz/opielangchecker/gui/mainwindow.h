#ifndef OPIE_LANG_CHECK_WINDOW_HAUPT_FENSTER_H
#define OPIE_LANG_CHECK_WINDOW_HAUPT_FENSTER_H

#include <message.h>

#include <kparts/mainwindow.h>

namespace KParts {
    class PartManager;
}

class MainWindow : public KParts::MainWindow {
    Q_OBJECT
public:
    MainWindow( const QString& tr = QString::null,
                const QString& file = QString::null );
    ~MainWindow();

signals:
    void alChanged(const LangCheck::Message::ValueList& );
    void trChanged(const LangCheck::Message::ValueList& );
    void langChanged();

protected:
    void saveProperties( KConfig*  );
    void readProperties( KConfig*  );

public slots:
    void setTrFile( const QString& file );
    void setAlFile( const QString& file );
    void newToolbarConfig();

private slots:
    void optionsShowToolbar();
    void optionsShowStatusbar();
    void optionsConfigureKeys();
    void optionsConfigureToolbars();
    void slotActivePartChanged( KParts::Part* );

    void slotLoadTr();
    void slotLoadAl();

private:
    void initActions();
    void initUI();
    QString downloadFile( const QString& caption );

    QString m_trFile;
    QString m_alFile;
    LangCheck::Message::ValueList m_trMessages, m_alMessages;
    KParts::PartManager* m_partMan;
};



#endif

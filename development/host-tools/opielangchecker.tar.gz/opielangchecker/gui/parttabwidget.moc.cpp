/****************************************************************************
** PartTabWidget meta object code from reading C++ file 'parttabwidget.h'
**
** Created: Sun Jun 8 19:48:46 2003
**      by: The Qt MOC ()
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "parttabwidget.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.2.0b1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *PartTabWidget::className() const
{
    return "PartTabWidget";
}

QMetaObject *PartTabWidget::metaObj = 0;
static QMetaObjectCleanUp cleanUp_PartTabWidget( "PartTabWidget", &PartTabWidget::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString PartTabWidget::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "PartTabWidget", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString PartTabWidget::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "PartTabWidget", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* PartTabWidget::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QTabwidget::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_ptr, "QWidget", QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotCurrentChanged", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "slotCurrentChanged(QWidget*)", &slot_0, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"PartTabWidget", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_PartTabWidget.setMetaObject( metaObj );
    return metaObj;
}

void* PartTabWidget::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "PartTabWidget" ) )
	return this;
    return QTabwidget::qt_cast( clname );
}

bool PartTabWidget::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotCurrentChanged((QWidget*)static_QUType_ptr.get(_o+1)); break;
    default:
	return QTabwidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool PartTabWidget::qt_emit( int _id, QUObject* _o )
{
    return QTabwidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool PartTabWidget::qt_property( int id, int f, QVariant* v)
{
    return QTabwidget::qt_property( id, f, v);
}

bool PartTabWidget::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES

#include <kparts/mainwindow.h>

#include "langpart.h"


LangPart::LangPart( KParts::MainWindow* par, const char* name )
    : KParts::Part( par, name ) {
    connect( par, SIGNAL(trChanged(const LangCheck::Message::ValueList& ) ),
             this, SLOT(slotTrChanged(const LangCheck::Message::ValueList& ) ) );
    connect( par, SIGNAL(alChanged(const LangCheck::Message::ValueList& ) ),
             this, SLOT(slotAlChanged(const LangCheck::Message::ValueList& ) ) );
    connect( par, SIGNAL(langChanged() ),
             this, SIGNAL(langChanged() ) );
    m_parWid = par->centralWidget();
}
LangPart::~LangPart() {
}

void LangPart::clearContent() {
}
QWidget* LangPart::parentWidget()const {
    return m_parWid;
}
LangCheck::Message::ValueList LangPart::trMessages()const{
    return m_trMes;
}
LangCheck::Message::ValueList LangPart::alMessages()const{
    return m_alMes;
}

/*
 * first emit and then change the list
 * this way one can access new and old at the same time
 */
void LangPart::slotTrChanged( const LangCheck::Message::ValueList& list ) {
    emit trChanged( list );
    m_trMes = list;
}
void LangPart::slotAlChanged( const LangCheck::Message::ValueList& list ) {
    emit alChanged( list );
    m_alMes = list;
}


#include "langpart.moc"


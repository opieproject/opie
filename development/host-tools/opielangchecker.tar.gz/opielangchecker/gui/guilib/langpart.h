#ifndef OPIE_LANGUAGE_CHECK_PART_H
#define OPIE_LANGUAGE_CHECK_PART_H

#include <kparts/part.h>

#include <message.h>

/**
 * Interface to have access to the language set
 */

namespace KParts {
    class MainWindow;
}
class LangPart : public KParts::Part {
    Q_OBJECT
public:
    /**
     * this will use centralWidget as parent
     * and also connect to signals of the mainwindow
     */
    LangPart( KParts::MainWindow*,  const char* name );
    ~LangPart();

    /**
     * the host asks the View to save memory
     */
    virtual void clearContent();

    virtual QString tabName()const = 0;
protected:
    QWidget* parentWidget()const;
    LangCheck::Message::ValueList trMessages()const;
    LangCheck::Message::ValueList alMessages()const;

signals:
    void trChanged(const LangCheck::Message::ValueList& newList);
    void alChanged(const LangCheck::Message::ValueList& newList);
    void langChanged();

private slots:
    void slotTrChanged( const LangCheck::Message::ValueList& );
    void slotAlChanged( const LangCheck::Message::ValueList& );

private:
    /* save it here to be really independant of the MainWindow */
    LangCheck::Message::ValueList m_trMes;
    LangCheck::Message::ValueList m_alMes;
    QWidget* m_parWid;

};


#endif

/****************************************************************************
** MainWindow meta object code from reading C++ file 'mainwindow.h'
**
** Created: Fri Jun 6 22:43:25 2003
**      by: The Qt MOC ()
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "mainwindow.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.2.0b1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *MainWindow::className() const
{
    return "MainWindow";
}

QMetaObject *MainWindow::metaObj = 0;
static QMetaObjectCleanUp cleanUp_MainWindow( "MainWindow", &MainWindow::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString MainWindow::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MainWindow", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString MainWindow::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MainWindow", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* MainWindow::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = KMainWindow::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "file", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"setTrFile", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "file", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"setAlFile", 1, param_slot_1 };
    static const QUMethod slot_2 = {"newToolbarConfig", 0, 0 };
    static const QUMethod slot_3 = {"optionsShowToolbar", 0, 0 };
    static const QUMethod slot_4 = {"optionsShowStatusbar", 0, 0 };
    static const QUMethod slot_5 = {"optionsConfigureKeys", 0, 0 };
    static const QUMethod slot_6 = {"optionsConfigureToolbars", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "setTrFile(const QString&)", &slot_0, QMetaData::Public },
	{ "setAlFile(const QString&)", &slot_1, QMetaData::Public },
	{ "newToolbarConfig()", &slot_2, QMetaData::Public },
	{ "optionsShowToolbar()", &slot_3, QMetaData::Private },
	{ "optionsShowStatusbar()", &slot_4, QMetaData::Private },
	{ "optionsConfigureKeys()", &slot_5, QMetaData::Private },
	{ "optionsConfigureToolbars()", &slot_6, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"MainWindow", parentObject,
	slot_tbl, 7,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_MainWindow.setMetaObject( metaObj );
    return metaObj;
}

void* MainWindow::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "MainWindow" ) )
	return this;
    return KMainWindow::qt_cast( clname );
}

bool MainWindow::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: setTrFile((const QString&)static_QUType_QString.get(_o+1)); break;
    case 1: setAlFile((const QString&)static_QUType_QString.get(_o+1)); break;
    case 2: newToolbarConfig(); break;
    case 3: optionsShowToolbar(); break;
    case 4: optionsShowStatusbar(); break;
    case 5: optionsConfigureKeys(); break;
    case 6: optionsConfigureToolbars(); break;
    default:
	return KMainWindow::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool MainWindow::qt_emit( int _id, QUObject* _o )
{
    return KMainWindow::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool MainWindow::qt_property( int id, int f, QVariant* v)
{
    return KMainWindow::qt_property( id, f, v);
}

bool MainWindow::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES

#include "parttabwidget.h"

PartTabWidget::PartTabWidget( QWidget* parent, KParts::PartManager* man,
                              const char* name )
    : QTabWidget( parent, name ), m_manager( man ) {
    connect( this, SIGNAL(currentChanged(QWidget*) ),
             this, SLOT(slotCurrentChanged(QWidget* ) ) );
}
PartTabWidget::~PartTabWidget() {
}
void PartTabWidget::addTab( LangPart* part ) {
    QTabWidget::addTab( part->widget(), part->tabName() );
    m_manager->addPart( part );
    m_parts.insert( part->widget(), part );
}
void PartTabWidget::slotCurrentChanged( QWidget* wid ) {
    QMap<QWidget*, LangPart*>::Iterator it = m_parts.find( wid );
    if ( it == m_parts.end() )
        return;

    // now tell the part manager who is active and this will trigger a signal..
    m_manager->setActivePart( it.data() );
}



#include "parttabwidget.moc"

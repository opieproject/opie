#include <qfile.h>

#include <kaboutdata.h>
#include <kcmdlineargs.h>
#include <kapplication.h>

#include "mainwindow.h"

static KCmdLineOptions options[] = {
    { "tr", I18N_NOOP("The tr file"), 0 },
    { "all", I18N_NOOP("The file containing all messafes"), 0 },
    KCmdLineLastOption
};

int main( int argc, char* argv[] ) {
    KAboutData aboutData("LangChecker" ,I18N_NOOP("Opie Lang Checker"), "0.0.0.0.0.0.0.",
                         "Display .po files and check differences",
                         KAboutData::License_GPL,
                         "(C) 2003 Opie Language Team",
                         0,
                         "http://opie.handhelds.org" );
    aboutData.addAuthor("Zecke", I18N_NOOP("Slave to the wages"),
                        "zecke@handhelds.org" );
    aboutData.addCredit("Alexandra Chalupka", I18N_NOOP("For her support und understanding of my fscked up health"),  0 );
    aboutData.addCredit("Mama :)", "F�r ihre Unterst�tzung und derzeitige Pflege", 0 );

    KCmdLineArgs::init( argc, argv, &aboutData );
    KCmdLineArgs::addCmdLineOptions( options );
    KApplication::addCmdLineOptions();


    KApplication app;

    if (app.isRestored() ) {
        RESTORE( MainWindow )
    }else{
        QString tr, all;
        KCmdLineArgs* args = KCmdLineArgs::parsedArgs();

        if ( args->isSet("tr") )
            tr = QFile::decodeName( args->getOption("tr") );
        if ( args->isSet("all") )
            all = QFile::decodeName( args->getOption("all") );
        args->clear();

        MainWindow *win = new MainWindow(tr, all );
        win->show();
        //      win->setSize(300, 400 );
    }


    return app.exec();

}

#ifndef SPELL_VIEW_PAT_H
#define SPELL_VIEW_PAT_H

#include <langpart.h>


class SpellView : public LangPart {
    Q_OBJECT
public:
    SpellView( KParts::MainWindow* );
    ~SpellView();

    QString tabName()const;

};


#endif

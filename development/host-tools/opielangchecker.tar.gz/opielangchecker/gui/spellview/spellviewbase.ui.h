/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/


void SpellViewBase::slotNext()
{    
    m_current++;
    m_it++;
    if(m_current >= m_list.count() )
	slotBegin();
    else
	displayCurrent();
}


void SpellViewBase::slotPrev()
{
    if(m_current == 0 )
	return;
    
    
    m_current--;
    m_it--;
    displayCurrent();
}


void SpellViewBase::slotBegin()
{
    m_current = 0;
    m_it = m_list.begin();
    displayCurrent();
}


void SpellViewBase::slotEnd()
{
    m_it = m_list.end();
    --m_it;
    m_current = m_list.count() == 0 ? 0 : m_list.count()-1;
    displayCurrent();
}


void SpellViewBase::slotTrChanged( const LangCheck::Message::ValueList & list)
{
    m_list = list;
    slotBegin();
}
void SpellViewBase::init(){
    m_current = 0;
    txtEdit->setReadOnly(true);
    txtEdit->setCheckSpellingEnabled( true );
}


LangCheck::Message::ValueList SpellViewBase::trMessage()
{
    return m_list;
}


void SpellViewBase::displayCurrent()
{
    if( m_it == m_list.end() )
	return;
    
    txtMessages->setText(i18n("<b>Message</b> %1 of %2").arg( m_current+1 ).arg( m_list.count() ) );
 
    LangCheck::Context::ValueList list = (*m_it).contexts();
    QString context;
    for(LangCheck::Context::ValueList::Iterator it = list.begin(); it != list.end(); ++it ){
	context += (*it).fileName()+":" +QString::number( (*it).lineNumber() )+ " ";
    }
    txtContext->setText(context);
    txtEdit->setText( (*m_it).message() );
}


void SpellViewBase::slotSpellThis()
{
    txtEdit->checkSpelling();
    kdDebug() << "Spell checking done" << endl;
}

/*
  * checkSpelling does return immediately some how..
  * so we need to put all messages into the ktextedit and then check it
  */
void SpellViewBase::slotSpellAll()
{
    LangCheck::Message::ValueList::Iterator it;
    QString message;
    
    int cur = 1;
    
    for( it  = m_list.begin(); it != m_list.end(); ++it ){
	message += QString::number(cur)+ ".  " + (*it).message() + "\n";
	cur++;
    }    
    
    txtEdit->setText(message);
    txtEdit->checkSpelling();
}

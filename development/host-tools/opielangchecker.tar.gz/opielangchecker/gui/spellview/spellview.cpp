#include <qlabel.h>

#include <kdebug.h>
#include <kaction.h>
#include <klocale.h>

#include "spellviewbase.h"
#include "spellview.h"

SpellView::SpellView( KParts::MainWindow* win )
    : LangPart( win, "SpellView") {
    kdDebug() << "SpellView yeah" << endl;
    setInstance( KGlobal::instance() ); // no need for the catalogue..
    setXMLFile("spellviewui.rc"); // hope the instance is the right one

    QWidget* lbl = new SpellViewBase( parentWidget() );
    connect(this, SIGNAL(trChanged(const LangCheck::Message::ValueList& ) ),
            lbl, SLOT(slotTrChanged(const LangCheck::Message::ValueList& ) ) );
    (void)new KAction( i18n("Next String"), "next", 0,
                       lbl, SLOT(slotNext() ),
                       actionCollection(), "next_string" );
    (void)new KAction( i18n("Prev String"), "prev", 0,
                       lbl, SLOT(slotPrev() ),
                       actionCollection(), "prev_string" );
    (void)new KAction( i18n("First String"), "first", 0,
                       lbl, SLOT(slotBegin() ),
                       actionCollection(), "first_string" );
    (void)new KAction( i18n("Last String"), "last", 0,
                       lbl, SLOT(slotEnd() ),
                       actionCollection(), "last_string");
    (void)new KAction( i18n("Spellcheck this"), "spell", 0,
                       lbl, SLOT(slotSpellThis() ),
                       actionCollection(), "spell_one");
    (void)new KAction( i18n("Spellcheck all"), "spell", 0,
                       lbl, SLOT(slotSpellAll() ),
                       actionCollection(), "spell_all" );
    (void)new KAction( i18n("Stylecheck this"), "style", 0,
                       this, SLOT(foo() ),
                       actionCollection(), "style_one");
    (void)new KAction( i18n("Stylecheck all"), "style", 0,
                       this, SLOT( foo() ) ,
                       actionCollection(), "style_all" );

    setWidget( lbl );

}
SpellView::~SpellView() {
}
QString SpellView::tabName()const{
    return i18n("Spell View");
}

#include "spellview.moc"

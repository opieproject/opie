// GPL by zecke

#ifndef LANG_CHECK_CONTEXT_H
#define LANG_CHECK_CONTEXT_H

#include <qstring.h>
#include <qvaluelist.h>


namespace LangCheck {

    /**
     * A Context in this case is where a string from a @see Message
     * was found.
     * We will use filename and line number
     */
    class Context {
    public:
        typedef QValueList<Context> ValueList;
        /**
         * simple c'tor to construct a Context
         * @param file The filename of the Context
         * @param lineNumber The linenumber inside the file
         */
        Context( const QString& file = QString::null, unsigned int lineNumber = 0);
        ~Context();


        bool operator==( const Context& )const;
        bool operator!=( const Context& )const;
        /**
         * return the lineNumber of the Context
         * @return The line number
         */
        unsigned int lineNumber()const;

        /**
         * returns the file name as QString
         * @return The filename
         */
        QString fileName()const;


        /**
         * set the line number
         * @param lineNumber the line number to be set
         */
        void setLineNumber( unsigned int lineNumber );

        /**
         * set the file name
         */
        void setFileName( const QString& fileName );

    private:
        QString m_fileName;
        unsigned int m_lineNumber;
    };
}


#endif

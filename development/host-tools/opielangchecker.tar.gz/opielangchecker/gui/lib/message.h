// GPL as well

//#include <qstring.h>
//#include <qvaluelist.h>

#ifndef LANG_CHECK_MESSAGE_H
#define LANG_CHECK_MESSAGE_H

#include "context.h"

namespace LangCheck {


    /**
     * A message is the original string
     * A message contains contextes were it occurs
     */
    class Message {
    public:
        typedef QValueList<Message> ValueList;
        Message( const QString& text = QString::null,
                 const Context::ValueList& list = Context::ValueList() );
        ~Message();

        QString message()const;
        void setMessage( const QString& );

        void removeContext( const Context& con );
        void insertContext( const Context& con );
        Context::ValueList contexts()const;
        void setContexts( const Context::ValueList& );

        Context::ValueList contextByLine( unsigned int line );
        Context::ValueList contextByFile( const QString& file );

    private:
        QString m_string;
        Context::ValueList m_context;
    };
}

#endif

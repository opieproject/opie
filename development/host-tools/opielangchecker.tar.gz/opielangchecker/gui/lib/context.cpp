#include "context.h"

using namespace LangCheck;


Context::Context( const QString& file, unsigned int line )
    : m_fileName( file ), m_lineNumber( line ) {
}
Context::~Context() {
}
unsigned int Context::lineNumber()const {
    return m_lineNumber;
}
QString Context::fileName()const {
    return m_fileName;
}
void Context::setFileName( const QString& fileName ) {
    m_fileName = fileName;
}
void Context::setLineNumber( unsigned int lineNumber ) {
    m_lineNumber = lineNumber;
}
bool Context::operator==( const Context& con) const{
    if ( m_fileName != con.m_fileName ) return false;
    if ( m_lineNumber != con.m_lineNumber ) return false;

    return true;
}
bool Context::operator!=( const Context& con ) const {
    return !(*this == con );
}

#include <qfile.h>
#include <qcstring.h>
#include <qstringlist.h>
#include <qtextstream.h>

#include "reader.h"

using namespace LangCheck;

Reader::Reader() {
}
Reader::~Reader() {
}

bool Reader::loadFile( const QString& fileName ) {
    m_messages.clear();

    QFile file( fileName );
    if (!file.open(IO_ReadOnly) )
        return false;

    QTextStream stream( &file );
    QString line;

    // skip the beginning until new empty line is hit
    while ( !stream.atEnd() ) {
        line = stream.readLine();
        if ( line.stripWhiteSpace().isEmpty() )
            break; // leave now
    }

    int status = Con;
    Message cont; // cont from context

    while ( !stream.atEnd() ) {

        /*
         * simple states
         */
        line = stream.readLine();
        if (line.startsWith("#:" ) )
            status = Con;
        else if ( line.startsWith("msgid") )
            status = Msg;
        else if ( line.startsWith("msgstr") )
            continue;
        else if ( line.stripWhiteSpace().isEmpty() )
            status = Commit;
        // else two line Msg

        switch( status ) {
        case Con:
            handleCon( line, cont );
            break;
        case Msg:
            handleMsg( line, cont );
            break;
        case Commit:
            m_messages.append( cont );
            cont = Message();
            break;
        }

    }
    // append the last..
    if (!cont.message().isEmpty() )
        m_messages.append( cont );

    return true;
}
Message::ValueList Reader::messages()const {
    return m_messages;
}
// msgid "opie-contactfield-order"
void Reader::handleMsg( const QString& line, Message& msg ) {
    QString text = msg.message(); // could already contain text
    int left, right;
    left = line.find('\"' );
    right = line.findRev('\"' );
    if (left != -1 && right != -1 ) {
        qWarning(" string is %s", line.mid( left+1, right-(left+1) ).latin1() );
        text.append( line.mid( left+1, right-(left+1) ) );
        msg.setMessage( text );
    }
}

// #: ocontactfields.h:10 contacteditor.cpp:1242
void Reader::handleCon( const QString& _line, Message& msg ) {
    QString line = _line.mid(3 );

    QStringList list = QStringList::split(' ', line );
    Context::ValueList cons = msg.contexts();
    for (QStringList::Iterator it = list.begin(); it != list.end();++it ) {
        QStringList con = QStringList::split(':', (*it) );
        Context context( con[0], con[1].toUInt() );
        qWarning("Context is %s %s", con[0].latin1(), con[1].latin1() );
        cons.append( context );
    }

    msg.setContexts( cons );
}

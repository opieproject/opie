#include "reader.h"
#include "manager.h"

using namespace LangCheck;

int main( int argc, char* argv[] ) {
    if (argc < 2 )
        return -1;

    Reader reader;
    if (reader.loadFile( QString::fromLocal8Bit( argv[1] ) ) ) {
        qWarning("loaded %d", reader.messages().count() );

        if (argc == 3 ) {
            Manager::writeToXml( QString::fromLocal8Bit( argv[2] ), reader.messages() );
        }
    }

    return 0;
}

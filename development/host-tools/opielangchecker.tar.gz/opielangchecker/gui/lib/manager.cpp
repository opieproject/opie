#include <qfile.h>
#include <qtextstream.h>

#include "manager.h"

using namespace LangCheck;
//using namespace LangCheck::Manager;

namespace {
    Context::ValueList diffContext( const Context::ValueList& tr, const Context::ValueList& all) {
        Context::ValueList con;
        for (Context::ValueList::ConstIterator allIt =  all.begin(); allIt != all.end(); ++allIt ) {
            if (!tr.contains( (*allIt) ) )
                con.append( (*allIt) );

        }
        return con;
    }
}

/*
 * we will find all messages and contextes which are not handled inside
 * the tred one..
 * go through all AllMessages and see if it is in tr use the text and not operator==
 * if found see which contexts are unhandled..
 */
Message::ValueList Manager::findUnhandled( const Message::ValueList& trs, const Message::ValueList& all ) {
    Message::ValueList unhand;
    bool found;
    Message::ValueList::ConstIterator trIt;
    for (Message::ValueList::ConstIterator allIt = all.begin(); allIt != all.end(); ++allIt ) {
        found = false;

        for (trIt = trs.begin(); trIt != trs.end(); ++trIt ) {
            if ( (*trIt).message().stripWhiteSpace() == (*allIt).message().stripWhiteSpace() ) {
                found = true;
                /* now we need to check the context */
                if ( (*trIt).contexts() != (*allIt).contexts() ) {
                    Context::ValueList cons = diffContext( (*trIt).contexts(), (*allIt).contexts() );
                    Message msg( (*trIt).message(), cons );
                    unhand.append( msg );
                }
                break;
            }
        }
        if (!found )
            unhand.append( (*allIt) );
    }

    return unhand;
}


static QString escapeString( const QString& plain )
{
    QString tmp(plain);

    return tmp; // for now where aspell is stupid


    int pos = tmp.length();
    const QChar *uc = plain.unicode();
    while ( pos-- ) {
	unsigned char ch = uc[pos].latin1();
	if ( ch == '&' )
	    tmp.replace( pos, 1, "&amp;" );
	else if ( ch == '<' )
	    tmp.replace( pos, 1, "&lt;" );
	else if ( ch == '>' )
	    tmp.replace( pos, 1, "&gt;" );
	else if ( ch == '\"' )
	    tmp.replace( pos, 1, "&quot;" );
    }
    return tmp;
}
/*
 * Layout of the file
 * <Language>
 *  <String>
 *    <Context src="filename.cpp" line="400" />
 *    <Context src="filename2.cpp" line="400" />
 *    <Message>Foo Message Escaped then</Message>
 *  </String>
 *
 * </Language>
 */
void Manager::writeToXml( const QString& _file, const Message::ValueList& list) {
    QFile file( _file );
    if (!file.open(IO_WriteOnly) )
        return;

    QTextStream stream( &file );
    stream << "<Language>\n";

    Message::ValueList::ConstIterator it;
    for ( it = list.begin(); it != list.end(); ++it ) {
        stream << "\t<String>\n";
        Context::ValueList conList = (*it).contexts();
        for (Context::ValueList::Iterator conIt = conList.begin(); conIt != conList.end(); ++conIt ) {
            stream << "\t\t<Context src=\""+ (*conIt).fileName() +"\" line=\""+ QString::number( (*conIt).lineNumber() ) + "\" />\n";
        }
        stream << "\t\t<Message>" + escapeString( (*it).message() ) + "</Message>\n";
        stream << "\t</String>\n";
    }


    stream << "</Language>\n";
}

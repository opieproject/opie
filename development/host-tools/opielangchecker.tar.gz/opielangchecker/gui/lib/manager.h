// GPL

#ifndef LANG_CHECK_MANAGER_H
#define LANG_CHECK_MANAGER_H

#include "message.h"

namespace LangCheck {


    /**
     * A small manager / query master
     * -It will help us to find which strings are in one set
     *  but not in the other..
     * -It will show us
     */
    class Manager {
    public:
        /**
         * @param the tred messages
         * @param all All messages found in the .po
         */

        static Message::ValueList findUnhandled( const Message::ValueList& trs, const Message::ValueList& all );

        /**
         * will write the messages including contextes to a XML file...
         */
        static void writeToXml( const QString& file, const Message::ValueList& );

    };
}


#endif

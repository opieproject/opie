#include "message.h"

using namespace LangCheck;


Message::Message( const QString& text,
                  const Context::ValueList& list )
    : m_string( text ), m_context( list ) {
}
Message::~Message() {
}
QString Message::message()const {
    return m_string;
}
void Message::setMessage( const QString& msg) {
    m_string = msg;
}
void Message::removeContext( const Context& con ) {
    m_context.remove( con );
}
void Message::insertContext( const Context& con ) {
    m_context.append( con );
}
Context::ValueList Message::contexts()const{
    return m_context;
}
void Message::setContexts( const Context::ValueList& list) {
    m_context = list;
}
Context::ValueList Message::contextByLine( unsigned int line ) {
    Context::ValueList list;

    for (Context::ValueList::Iterator it = m_context.begin(); it != m_context.end(); ++it ) {
        if ( (*it).lineNumber() == line )
            list.append( (*it) );
    }

    return list;
}
Context::ValueList Message::contextByFile( const QString& file ) {
    Context::ValueList list;
    for (Context::ValueList::Iterator it = m_context.begin(); it != m_context.end(); ++it ) {
        if ( (*it).fileName() == file )
            list.append( (*it) );
    }

    return list;
}

// GPL

#ifndef LANG_CHECK_READER_H
#define LANG_CHECK_READER_H

#include "message.h"

namespace LangCheck {

    /**
     * reads in a .po file
     */
    class Reader {
        enum Cont { Commit = 0,
                       Msg,
                       Con };
    public:
        Reader();
        ~Reader();

        bool loadFile( const QString& fileName );

        Message::ValueList messages()const;

    private:
        void handleMsg( const QString&, Message&  );
        void handleCon( const QString&, Message&  );
        Message::ValueList m_messages;

    };
}

#endif

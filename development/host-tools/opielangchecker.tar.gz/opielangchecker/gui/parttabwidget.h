#ifndef OPIE_LANG_CHECK_PART_MANAGED_TAB_WIDGET
#define OPIE_LANG_CHECK_PART_MANAGED_TAB_WIDGET

#include <qmap.h>
#include <qtabwidget.h>

#include <kparts/partmanager.h>

#include <guilib/langpart.h>

/**
 * tabwidget which place nice with Parts and PartManager
 */
class PartTabWidget : public QTabWidget {
    Q_OBJECT
public:
    PartTabWidget( QWidget* parent, KParts::PartManager*, const char* name = 0);
    ~PartTabWidget();

    void addTab( LangPart* part );

private slots:
    void slotCurrentChanged( QWidget* );

private:
    QMap<QWidget*, LangPart*> m_parts;
    KParts::PartManager* m_manager;
};


#endif

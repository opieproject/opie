#include <kaction.h>
#include <klocale.h>
#include <kglobal.h>
#include <klistview.h>

#include <manager.h>

#include "diffviewbase.h"
#include "diffview.h"


DiffView::DiffView( KParts::MainWindow* win )
    : LangPart( win, "DiffView" ) {
    setInstance( KGlobal::instance() );
    setXMLFile( "diffviewui.rc" );

    (void)new KAction( i18n("ReDiff"), "diff", 0,
                       this, SLOT( slotLangChanged() ),
                       actionCollection(), "re_diff" );

    m_base = new DiffViewBase( parentWidget() );
    setWidget( m_base );

    connect(this, SIGNAL(langChanged() ),
            SLOT(slotLangChanged() ) );
}
DiffView::~DiffView() {
}
void DiffView::slotLangChanged() {
    KListView* view = m_base->listView();
    view->clear();

    /* first diff then add */
    LangCheck::Message::ValueList un = LangCheck::Manager::findUnhandled( trMessages(), alMessages() );

    LangCheck::Message::ValueList::Iterator it;
    for ( it = un.begin(); it != un.end(); ++it ) {
        KListViewItem*  item = new KListViewItem( view, (*it).message() );
        item->setExpandable( true );
        LangCheck::Context::ValueList vals = (*it).contexts();
        for (LangCheck::Context::ValueList::Iterator conIt = vals.begin(); conIt != vals.end(); ++conIt )
            (void)new KListViewItem(item, (*conIt).fileName() + ":" + QString::number( (*conIt).lineNumber() ) );

    }

}
QString DiffView::tabName()const {
    return i18n("Diff View");
}



#include "diffview.moc"

#ifndef LANG_CHECK_DIFF_VIEW_H
#define LANG_CHECK_DIFF_VIEW_H

#include <langpart.h>

class DiffViewBase;
class DiffView : public LangPart {
    Q_OBJECT
public:
    DiffView( KParts::MainWindow* win );
    ~DiffView();

    QString tabName()const;

private slots:
    void slotLangChanged();

private:
    DiffViewBase* m_base;

};


#endif

#include <reader.h>

#include <kapplication.h>
#include <kstdaction.h>
#include <kkeydialog.h>
#include <kconfig.h>
#include <kdebug.h>
#include <klocale.h>

#include <kfiledialog.h>
#include <kurl.h>

#include <kio/netaccess.h>

#include <kparts/partmanager.h>



#include <guilib/langpart.h>
#include <spellview/spellview.h>
#include <diffview/diffview.h>
#include "parttabwidget.h"

#include "mainwindow.h"


MainWindow::MainWindow( const QString& tr,
                        const QString& al ) {


    setTrFile( tr );
    setAlFile( al );

    initActions();
    setInstance( KGlobal::instance() );
    setAutoSaveSettings();
    initUI();
}
MainWindow::~MainWindow() {
}
void MainWindow::saveProperties( KConfig* conf ) {
    conf->writeEntry( "Tr-File", m_trFile );
    conf->writeEntry( "Al-File", m_alFile );
}
void MainWindow::readProperties( KConfig* conf ) {
    setTrFile( conf->readEntry( "Tr-File") );
    setAlFile( conf->readEntry( "Al-File") );
}
void MainWindow::setTrFile( const QString& file ) {
    m_trMessages.clear();

    LangCheck::Reader r;
    if ( r.loadFile( file ) )
        m_trMessages = r.messages();

    kdDebug() << "Message count is " << m_trMessages.count() << endl;
}
void MainWindow::setAlFile( const QString& file ) {
    m_alMessages.clear();

    LangCheck::Reader r;
    if ( r.loadFile( file ) )
        m_alMessages = r.messages();
}
void MainWindow::initActions() {
    KStdAction::quit(kapp, SLOT(quit() ), actionCollection() );
    KStdAction::showToolbar(this, SLOT(optionsShowToolbar() ), actionCollection() );
    KStdAction::showStatusbar(this, SLOT(optionsShowStatusbar() ), actionCollection() );

    KStdAction::keyBindings( this, SLOT(optionsConfigureKeys() ), actionCollection() );
    KStdAction::configureToolbars(this, SLOT(optionsConfigureToolbars() ), actionCollection() );

    // the load actions
    (void)new KAction( i18n("Load 'tred' file"), "unknown_foo", 0,
                       this, SLOT(slotLoadTr() ),
                       actionCollection(), "load_tr" );
    (void)new KAction( i18n("Load all file"), "unknown_boo", 0,
                       this, SLOT(slotLoadAl() ),
                       actionCollection(), "load_al" );

}
void MainWindow::initUI() {
    setXMLFile( "olangcheckerui.rc" );
    m_partMan = new KParts::PartManager( this, "Part Manager");
    connect( m_partMan, SIGNAL(activePartChanged( KParts::Part* ) ),
             this, SLOT( slotActivePartChanged( KParts::Part* ) ) );


    PartTabWidget *wid = new PartTabWidget( this, m_partMan, "tab_widget" );
    setCentralWidget( wid );

    /* maybe use KTrader in the future but currently we do not plan that big.. */
    LangPart* part = new SpellView( this );
    wid->addTab( part );

    part = new DiffView( this );
    wid->addTab( part );
//    m_partMan->setActivePart( part );


}
void MainWindow::optionsShowToolbar() {
// not used yet
}
void MainWindow::optionsShowStatusbar() {
// not used yet
}
void MainWindow::optionsConfigureKeys() {
    KKeyDialog::configureKeys(actionCollection(), "OpieLangCheckui.rc" );
}
void MainWindow::optionsConfigureToolbars() {
    saveMainWindowSettings(KGlobal::config() );
}
void MainWindow::newToolbarConfig() {
    // this slot is called when user clicks "Ok" or "Apply" in the toolbar editor.
    // recreate our GUI, and re-apply the settings (e.g. "text under icons", etc.)
    createGUI(m_partMan->activePart() );

    applyMainWindowSettings( KGlobal::config() );
}
/* could directly connect to part manager... but we may want to do some mem clean ups late */
void MainWindow::slotActivePartChanged( KParts::Part* p) {
    createGUI( p );
}
void MainWindow::slotLoadAl() {
    QString str = downloadFile( i18n("Load All Messages from Opie") );
    setAlFile( str );
    KIO::NetAccess::removeTempFile( str ); // just in case
    emit alChanged( m_alMessages );
    emit langChanged();
}
void MainWindow::slotLoadTr() {
    QString str = downloadFile( i18n("Loadd Tr Messages from Opie") );
    setTrFile( str );
    KIO::NetAccess::removeTempFile( str );
    emit trChanged( m_trMessages );
    emit langChanged();
}
QString MainWindow::downloadFile( const QString& caption ) {
    KURL url = KFileDialog::getOpenURL(QString::null, QString::null, 0, caption);

    /* just return the url */
    if ( url.isLocalFile() ) {
        qWarning("fooo");
        kdDebug() << url << " Path " << url.path() << endl;
        return url.path();
    }
    QString temp;
    (void)KIO::NetAccess::download( url, temp );

        // FIXME warning for download failures...

    return temp;
}

#include "mainwindow.moc"

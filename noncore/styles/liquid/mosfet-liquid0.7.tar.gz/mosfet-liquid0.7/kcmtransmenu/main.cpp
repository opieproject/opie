
#include <kapp.h>
#include <klocale.h>
#include <kglobal.h>
#include <kcmodule.h>

#include "transmenu.h"

extern "C"
{

  KCModule *create_transmenu(QWidget *parent, const char *name)
  { 
    KGlobal::locale()->insertCatalogue("kcmtransmenu");
    return new TransMenuConfig(parent, name);
  }
}



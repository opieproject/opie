#ifndef __KCM_TRANSMENU_H
#define __KCM_TRANSMENU_H

#include <kcmodule.h>
#include <kstddirs.h>
#include <kcolorbutton.h>
#include <qpushbutton.h>

class QSlider;
class KColorButton;
class QGroupBox;
class QVButtonGroup;
class QRadioButton;

#define LIQUID_MENU_CHANGE 667

class TransMenuConfig : public KCModule
{
    Q_OBJECT
public:
    enum Buttons{None=0, StippledBg, StippledBtn, TransStippleBg,
        TransStippleBtn, Custom};
    TransMenuConfig(QWidget *parent=0, const char *name=0);
    ~TransMenuConfig();
    void save();
    void load();
    void defaults();
protected slots:
    void slotBtnGroupClicked(int id);
    void slotShadowBtnClicked();
protected:
    QSlider *opacitySlider;
    KColorButton *colorBtn;
    KColorButton *fgBtn;
    QGroupBox *editGroup;
    QVButtonGroup *btnGroup;
    QRadioButton *shadowBtn;
};




#endif


